

//  yaha  par all  question  kaa  object    banaya  h

var questions = [
    {
      question: "What is the capital of France?",
      answers: {
        a: "Berlin",
        b: "Madrid",
        c: "Paris"
      },
      correct: "c"
    },
    {
      question: "Which planet is known as the Red Planet?",
      answers: {
        a: "Earth",
        b: "Mars",
        c: "Jupiter"
      },
      correct: "b"
    },



    {
        question: "Who wrote 'Romeo and Juliet'?",
        answers: {
          a: "Charles Dickens",
          b: "William Shakespeare",
          c: "Jane Austen"
        },
        correct: "b"
      },
      {
        question: "What is the currency of Japan?",
        answers: {
          a: "Yuan",
          b: "Won",
          c: "Yen"
        },
        correct: "c"
      }  
    // Add more questions as needed
  ];


      function  load(){
    let  data = questions[index];
     console.log('hello');

      }

      load();